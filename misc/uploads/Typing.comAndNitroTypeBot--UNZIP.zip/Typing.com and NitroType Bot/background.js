// background.js — char-only DevTools typing with fallback & warning-suppression
console.log('[background] started (char-only, fallback-ready)');

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    console.log('[background] message received', msg);
    if (msg && msg.action === 'typeWithDebugger') {
        typeWithDebugger(msg.tabId, msg.sentence, msg.wpm, !!msg.jitter)
            .then((usedFallback) => {
                console.log('[background] typing done (usedFallback=%s)', !!usedFallback);
                sendResponse({ success: true, usedFallback: !!usedFallback });
            })
            .catch(err => {
                console.error('[background] typing error', err);
                sendResponse({ success: false, error: (err && err.message) || 'unknown' });
            });
        return true; // keep channel open for async response
    }
});

// small helper to wrap chrome.debugger.sendCommand in a Promise
function sendCommandPromise(target, method, params = {}) {
    return new Promise((resolve, reject) => {
        chrome.debugger.sendCommand(target, method, params, (result) => {
            if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
            resolve(result);
        });
    });
}

function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

// Warning-suppressor: only log the first N distinct warnings
const WARN_LIMIT = 6;
let warnCount = 0;

async function tryCharOnlyTyping(target, sentence, wpm = 60, jitter = false) {
    // chars per minute using 5-chars-per-word convention
    const charsPerMinute = Math.max(1, wpm * 5);
    const baseMs = 60000 / charsPerMinute; // target ms per character

    // tiny settle before starting to ensure focus/handlers are ready
    await wait(25);

    // If the very first character is a space, do a short keyDown/char/keyUp for that space,
    // because some pages ignore an initial space delivered only as 'char'.
    let startIndex = 0;
    if (sentence.length > 0 && sentence[0] === ' ') {
        try {
            // small micro timing to avoid overlaps
            await sendCommandPromise(target, 'Input.dispatchKeyEvent', {
                type: 'keyDown',
                key: ' ',
                code: 'Space',
                windowsVirtualKeyCode: 32,
                nativeVirtualKeyCode: 32,
                autoRepeat: false,
                isKeypad: false,
                modifiers: 0
            });
        } catch (err) {
            if (warnCount < WARN_LIMIT) {
                console.warn('[background] initial-space keyDown warning:', err && err.message);
                warnCount++;
            }
        }

        try {
            await sendCommandPromise(target, 'Input.dispatchKeyEvent', { type: 'char', text: ' ' });
        } catch (err) {
            // bubble up to allow fallback logic
            throw new Error(`char event failed for initial space: ${err && err.message}`);
        }

        try {
            await sendCommandPromise(target, 'Input.dispatchKeyEvent', {
                type: 'keyUp',
                key: ' ',
                code: 'Space',
                windowsVirtualKeyCode: 32,
                nativeVirtualKeyCode: 32,
                autoRepeat: false,
                isKeypad: false,
                modifiers: 0
            });
        } catch (err) {
            if (warnCount < WARN_LIMIT) {
                console.warn('[background] initial-space keyUp warning:', err && err.message);
                warnCount++;
            }
        }

        // wait a little after that first-space insertion to let page process it
        await wait(Math.max(20, Math.round(baseMs * 0.1)));
        startIndex = 1; // continue with remaining chars
    }

    for (let i = 0; i < sentence.length; i++) {
        const ch = sentence[i];

        if (ch === ' ') {
            // send a proper keyDown + keyUp for Space
            try {
                await sendCommandPromise(target, 'Input.dispatchKeyEvent', {
                    type: 'keyDown',
                    key: ' ',
                    code: 'Space',
                    windowsVirtualKeyCode: 32,
                    nativeVirtualKeyCode: 32,
                    autoRepeat: false,
                    isKeypad: false,
                    modifiers: 0
                });
                await wait(10); // tiny pause
                await sendCommandPromise(target, 'Input.dispatchKeyEvent', {
                    type: 'keyUp',
                    key: ' ',
                    code: 'Space',
                    windowsVirtualKeyCode: 32,
                    nativeVirtualKeyCode: 32,
                    autoRepeat: false,
                    isKeypad: false,
                    modifiers: 0
                });
            } catch (err) {
                console.warn('Space keyDown/Up failed:', err && err.message);
            }
        } else {
            // letters/numbers: char event
            try {
                await sendCommandPromise(target, 'Input.dispatchKeyEvent', { type: 'char', text: ch });
            } catch (err) {
                throw new Error(`char event failed for "${ch}": ${err && err.message}`);
            }
        }

        // wait for WPM timing
        const factor = jitter ? (1 + (Math.random() * 0.2 - 0.1)) : 1;
        const delay = Math.max(15, Math.round(baseMs * factor));
        await wait(delay);
    }
}


// Fallback: script-insert entire sentence into currently focused editable (page context)
async function fallbackInjectTextViaScripting(tabId, sentence) {
    try {
        const res = await chrome.scripting.executeScript({
            target: { tabId },
            func: (s) => {
                // This runs in page context.
                function isTextInput(node) {
                    if (!node) return false;
                    const tag = node.tagName;
                    if (!tag) return false;
                    if (tag === 'INPUT' || tag === 'TEXTAREA') {
                        const t = (node.type || '').toLowerCase();
                        return ['text', 'search', 'tel', 'url', 'email', 'password', ''].includes(t);
                    }
                    if (node.isContentEditable) return true;
                    return false;
                }

                // pick activeElement or first visible text target
                let target = document.activeElement;
                const visible = el => { try { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); } catch (e) { return false; } };
                if (!isTextInput(target) || !visible(target)) {
                    const maybe = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"],[contenteditable=""]'))
                        .find(n => visible(n) && isTextInput(n));
                    if (maybe) {
                        target = maybe;
                        try { target.focus({ preventScroll: true }); } catch (e) { try { target.focus(); } catch (_) { } }
                    }
                }

                if (!isTextInput(target)) {
                    return { ok: false, reason: 'no text target' };
                }

                try {
                    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
                        // replace selection with full sentence (so lesson's caret is preserved at end)
                        const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
                        const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : target.value.length;
                        if (typeof target.setRangeText === 'function') {
                            target.setRangeText(s, start, end, 'end');
                            target.selectionStart = target.selectionEnd = start + s.length;
                        } else {
                            const val = target.value || '';
                            target.value = val.slice(0, start) + s + val.slice(end);
                            target.selectionStart = target.selectionEnd = start + s.length;
                        }
                        target.dispatchEvent(new Event('input', { bubbles: true }));
                        target.dispatchEvent(new Event('change', { bubbles: true }));
                        return { ok: true };
                    } else if (target.isContentEditable) {
                        // brute-force: insert text at selection
                        const sel = window.getSelection();
                        if (sel && sel.rangeCount) {
                            const range = sel.getRangeAt(0);
                            range.deleteContents();
                            const node = document.createTextNode(s);
                            range.insertNode(node);
                            range.setStartAfter(node);
                            range.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(range);
                        } else {
                            target.innerText = (target.innerText || '') + s;
                        }
                        target.dispatchEvent(new Event('input', { bubbles: true }));
                        return { ok: true };
                    } else {
                        return { ok: false, reason: 'unsupported target' };
                    }
                } catch (e) {
                    return { ok: false, reason: 'exception ' + (e && e.message) };
                }
            },
            args: [sentence]
        });

        const result = res && res[0] && res[0].result;
        if (result && result.ok) return true;
        console.warn('[background] fallback injection result:', result);
        return false;
    } catch (err) {
        console.error('[background] fallback injection exception:', err && err.message);
        return false;
    }
}

async function typeWithDebugger(tabId, sentence, wpm = 60, jitter = false) {
    if (!tabId || typeof sentence !== 'string') throw new Error('Bad args to typeWithDebugger');
    const target = { tabId };

    return new Promise((resolve, reject) => {
        chrome.debugger.attach(target, '1.3', async () => {
            if (chrome.runtime.lastError) {
                return reject(new Error(chrome.runtime.lastError.message));
            }

            let detached = false;
            async function safeDetach() {
                if (detached) return;
                detached = true;
                try { chrome.debugger.detach(target, () => { }); } catch (e) { }
            }

            try {
                // Try Input.enable but ignore not-found; char often works without it
                try {
                    await sendCommandPromise(target, 'Input.enable');
                    console.log('[background] Input.enable OK');
                } catch (enableErr) {
                    if (warnCount < WARN_LIMIT) {
                        console.warn('[background] Input.enable not available (continuing):', enableErr && enableErr.message);
                        warnCount++;
                    } else if (warnCount === WARN_LIMIT) {
                        console.warn('[background] further Input.enable warnings suppressed');
                        warnCount++;
                    }
                }

                // Attempt char-only typing
                try {
                    await tryCharOnlyTyping(target, sentence, wpm, jitter);
                    await safeDetach();
                    return resolve(false); // false => fallback not used
                } catch (charErr) {
                    // char failed for some character(s); we will attempt fallback injection
                    if (warnCount < WARN_LIMIT) {
                        console.warn('[background] char-only typing failed; will try fallback injection:', charErr && charErr.message);
                        warnCount++;
                    } else if (warnCount === WARN_LIMIT) {
                        console.warn('[background] further char/dispatch warnings suppressed');
                        warnCount++;
                    }
                }

                // If we get here, char-only typing didn't work -> fallback
                const fallbackOk = await fallbackInjectTextViaScripting(tabId, sentence);

                await safeDetach();
                return resolve(!fallbackOk ? true : true); // used fallback (true) either way; caller just sees success
            } catch (err) {
                await safeDetach();
                return reject(err);
            }
        });
    });
}
