// popup.js
document.addEventListener('DOMContentLoaded', () => {
    const wpmInput = document.getElementById('wpm');
    const jitterCheckbox = document.getElementById('jitter');
    const nitroTypeMode = document.getElementById('nitroTypeMode');
    const previewDiv = document.getElementById('preview');
    const statusDiv = document.getElementById('status');
    const logDiv = document.getElementById('log');
    const previewBtn = document.getElementById('previewBtn');
    const typeBtn = document.getElementById('typeBtn');
    const fallbackBtn = document.getElementById('fallbackBtn');
    const copyBtn = document.getElementById('copyBtn');

    function log(...args) {
        const txt = args.map(a => (typeof a === 'string' ? a : JSON.stringify(a))).join(' ');
        console.log('[popup]', txt);
        logDiv.textContent = (logDiv.textContent ? logDiv.textContent + '\n' : '') + txt;
        logDiv.scrollTop = logDiv.scrollHeight;
    }

    async function getActiveTab() {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        return tabs && tabs[0];
    }

    async function getSentenceFromPage(tabId) {
        try {
            const results = await chrome.scripting.executeScript({
                target: { tabId },
                func: (isNitro) => {
                    let wordDivsSelector;
                    let letterDivsSelector;

                    if (isNitro)
                    {
                        wordDivsSelector = '.dash-word';
                        letterDivsSelector = '.dash-letter';
                    }
                    else
                    {
                        wordDivsSelector = '.screenBasic-word';
                        letterDivsSelector = '.letter.letter--basic.screenBasic-letter';
                    }
                    // TYPING.COM
                    // Word:    .screenBasic-word
                    // Letter:  .letter.letter--basic.screenBasic-letter
                    //
                    // NitroType
                    // Word:    .dash-word
                    // Letter:  .dash-letter

                    const wordDivs = document.querySelectorAll(wordDivsSelector);
                    const words = [];
                    wordDivs.forEach(word => {
                        const letters = word.querySelectorAll(letterDivsSelector);
                        let w = '';
                        letters.forEach(letter => {
                            const txt = (letter.textContent ?? '').replace(/\u00A0/g, ' ');
                            w += txt;
                        });
                        w = w.replace(/\s+/g, ' ').trim();
                        if (w.length) words.push(w);
                    });
                    return { sentence: words.join(' ').trim() };
                },
                args: [ !!nitroTypeMode.checked ]
            });
            const sentence = results && results[0] && results[0].result && results[0].result.sentence;
            log('getSentenceFromPage ->', sentence);
            return sentence || '';
        } catch (err) {
            log('getSentenceFromPage error:', err && err.message);
            return '';
        }
    }

    // Ensure there's a focused editable on the page; attempt to focus one if not.
    async function ensureFocusOnEditable(tabId) {
        try {
            const res = await chrome.scripting.executeScript({
                target: { tabId },
                func: () => {
                    function isVisible(el) {
                        try { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); } catch (e) { return false; }
                    }
                    function isTextInput(node) {
                        if (!node) return false;
                        const tag = node.tagName;
                        if (!tag) return false;
                        if (tag === 'INPUT' || tag === 'TEXTAREA') {
                            const t = (node.type || '').toLowerCase();
                            return ['text', 'search', 'tel', 'url', 'email', 'password', ''].includes(t);
                        }
                        if (node.isContentEditable) return true;
                        return false;
                    }

                    let target = document.activeElement;
                    if (isTextInput(target) && isVisible(target)) {
                        try { target.focus({ preventScroll: true }); } catch (e) { try { target.focus(); } catch (_) { } }
                        return { focused: true };
                    }

                    const maybe = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"],[contenteditable=""]'))
                        .find(n => isVisible(n) && isTextInput(n));
                    if (maybe) {
                        try { maybe.focus({ preventScroll: true }); } catch (e) { try { maybe.focus(); } catch (_) { } }
                        return { focused: true };
                    }
                    return { focused: false };
                }
            });
            const focused = res && res[0] && res[0].result && res[0].result.focused;
            log('ensureFocusOnEditable ->', focused);
            return !!focused;
        } catch (err) {
            log('ensureFocusOnEditable error:', err && err.message);
            return false;
        }
    }

    previewBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Fetching sentence...';
        log('Preview clicked');
        const tab = await getActiveTab();
        if (!tab) { statusDiv.textContent = 'No active tab.'; log('No active tab'); return; }
        const s = await getSentenceFromPage(tab.id);
        previewDiv.textContent = s || '(No sentence found — check selectors)';
        statusDiv.textContent = '';
    });

    copyBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Getting sentence…';
        log('Copy clicked');
        const tab = await getActiveTab();
        if (!tab) { statusDiv.textContent = 'No active tab.'; return; }
        const s = await getSentenceFromPage(tab.id);
        if (!s) {
            statusDiv.textContent = 'No sentence found to copy.'; previewDiv.textContent = ''; log('Nothing to copy'); return;
        }
        try {
            await navigator.clipboard.writeText(s);
            statusDiv.textContent = 'Copied to clipboard!';
            previewDiv.textContent = s;
            log('Copied sentence to clipboard');
        } catch (e) {
            statusDiv.textContent = 'Clipboard write failed in popup.';
            log('Clipboard write failed:', e && e.message);
        }
    });

    // Type using chrome.debugger via background
    typeBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Preparing DevTools typing...';
        log('Type (DevTools) clicked');
        const tab = await getActiveTab();
        if (!tab) { statusDiv.textContent = 'No active tab.'; log('No active tab'); return; }
        const sentence = await getSentenceFromPage(tab.id);
        if (!sentence) { statusDiv.textContent = 'No sentence found'; previewDiv.textContent = ''; return; }
        previewDiv.textContent = sentence;

        // Ensure focus
        statusDiv.textContent = 'Focusing editable on page...';
        const focused = await ensureFocusOnEditable(tab.id);
        if (!focused) {
            statusDiv.textContent = 'Please click into the Typing.com text box first.';
            log('No focusable editable found; aborting');
            return;
        }

        statusDiv.textContent = 'Requesting background to type (you may see a permission prompt)...';
        chrome.runtime.sendMessage({
            action: 'typeWithDebugger',
            tabId: tab.id,
            sentence,
            wpm: Math.max(1, Math.min(400, parseInt(wpmInput.value || '60', 10))),
            jitter: !!jitterCheckbox.checked
        }, (response) => {
            if (!response) {
                statusDiv.textContent = 'No response from background.';
                log('No response from background');
                return;
            }
            if (response.success) {
                statusDiv.textContent = 'Typed via DevTools protocol!';
                log('DevTools typing succeeded');
            } else {
                statusDiv.textContent = 'DevTools typing failed: ' + (response.error || 'unknown');
                log('DevTools typing failed:', response.error);
            }
        });
    });

    // Fallback: try synthetic-keyboard approach (in-page)
    fallbackBtn.addEventListener('click', async () => {
        statusDiv.textContent = 'Preparing synthetic typing...';
        log('Synthetic Type clicked');
        const tab = await getActiveTab();
        if (!tab) { statusDiv.textContent = 'No active tab.'; return; }
        const sentence = await getSentenceFromPage(tab.id);
        if (!sentence) { statusDiv.textContent = 'No sentence found'; previewDiv.textContent = ''; return; }
        previewDiv.textContent = sentence;

        // Attempt to focus
        statusDiv.textContent = 'Focusing editable on page...';
        const focused = await ensureFocusOnEditable(tab.id);
        if (!focused) {
            statusDiv.textContent = 'Please click into the Typing.com text box first.';
            log('No focusable editable found; aborting synthetic typing');
            return;
        }

        statusDiv.textContent = 'Injecting synthetic-typing function...';
        try {
            const res = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: async (sentenceArg, wpmArg, jitterArg) => {
                    // This runs inside the page
                    const sleep = ms => new Promise(r => setTimeout(r, ms));
                    function charToKeyProps(ch) {
                        if (ch === '\n' || ch === '\r') return { key: 'Enter', code: 'Enter', keyCode: 13, charCode: 13 };
                        if (ch === ' ') return { key: ' ', code: 'Space', keyCode: 32, charCode: 32 };
                        const kc = ch.charCodeAt(0) || 0;
                        const upper = ch.toUpperCase();
                        if (upper >= 'A' && upper <= 'Z') return { key: ch, code: 'Key' + upper, keyCode: kc, charCode: kc };
                        if (ch >= '0' && ch <= '9') return { key: ch, code: 'Digit' + ch, keyCode: kc, charCode: kc };
                        return { key: ch, code: '', keyCode: kc, charCode: kc };
                    }

                    // find target
                    let target = document.activeElement;
                    const isVisible = el => { try { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); } catch (e) { return false; } };
                    const isTextInput = node => {
                        if (!node) return false;
                        const tag = node.tagName;
                        if (!tag) return false;
                        if (tag === 'INPUT' || tag === 'TEXTAREA') {
                            const t = (node.type || '').toLowerCase();
                            return ['text', 'search', 'tel', 'url', 'email', 'password', ''].includes(t);
                        }
                        if (node.isContentEditable) return true;
                        return false;
                    };
                    if (!isTextInput(target) || !isVisible(target)) {
                        const maybe = Array.from(document.querySelectorAll('input,textarea,[contenteditable="true"],[contenteditable=""]'))
                            .find(n => isVisible(n) && isTextInput(n));
                        if (maybe) {
                            target = maybe;
                            try { target.focus({ preventScroll: true }); } catch (e) { try { target.focus(); } catch (_) { } }
                        }
                    }
                    if (!isTextInput(target)) return { success: false, error: 'No text target' };

                    const charsPerMinute = Math.max(1, (wpmArg || 60) * 5);
                    const baseMs = 60000 / charsPerMinute;

                    for (let i = 0; i < sentenceArg.length; i++) {
                        const ch = sentenceArg[i];
                        const props = charToKeyProps(ch);
                        const jitterFactor = jitterArg ? (1 + (Math.random() * 0.2 - 0.1)) : 1;
                        const delay = Math.max(1, Math.round(baseMs * jitterFactor));

                        const kd = new KeyboardEvent('keydown', { key: props.key, code: props.code, keyCode: props.keyCode, charCode: props.charCode, bubbles: true, cancelable: true });
                        target.dispatchEvent(kd);
                        const kp = new KeyboardEvent('keypress', { key: props.key, code: props.code, keyCode: props.keyCode, charCode: props.charCode, bubbles: true, cancelable: true });
                        target.dispatchEvent(kp);

                        // update value/content
                        try {
                            if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') {
                                const start = typeof target.selectionStart === 'number' ? target.selectionStart : target.value.length;
                                const end = typeof target.selectionEnd === 'number' ? target.selectionEnd : start;
                                if (typeof target.setRangeText === 'function') {
                                    target.setRangeText(ch, start, end, 'end');
                                    target.selectionStart = target.selectionEnd = start + 1;
                                } else {
                                    const val = target.value || '';
                                    target.value = val.slice(0, start) + ch + val.slice(end);
                                    target.selectionStart = target.selectionEnd = start + 1;
                                }
                                target.dispatchEvent(new Event('input', { bubbles: true }));
                            } else if (target.isContentEditable) {
                                const sel = window.getSelection();
                                if (sel && sel.rangeCount) {
                                    const range = sel.getRangeAt(0);
                                    range.deleteContents();
                                    const node = document.createTextNode(ch);
                                    range.insertNode(node);
                                    range.setStartAfter(node);
                                    range.collapse(true);
                                    sel.removeAllRanges();
                                    sel.addRange(range);
                                } else {
                                    target.appendChild(document.createTextNode(ch));
                                }
                                target.dispatchEvent(new Event('input', { bubbles: true }));
                            } else {
                                target.textContent = (target.textContent || '') + ch;
                                target.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        } catch (e) { /* continue if insertion fails */ }

                        const ku = new KeyboardEvent('keyup', { key: props.key, code: props.code, keyCode: props.keyCode, charCode: props.charCode, bubbles: true, cancelable: true });
                        target.dispatchEvent(ku);

                        await sleep(delay);
                    }

                    return { success: true };
                },
                args: [sentence, Math.max(1, Math.min(400, parseInt(wpmInput.value || '60', 10))), !!jitterCheckbox.checked]
            });

            if (res && res[0] && res[0].result && res[0].result.success) {
                statusDiv.textContent = 'Synthetic typing attempted.';
                log('Synthetic typing injected - success');
            } else {
                statusDiv.textContent = 'Synthetic typing injection returned failure.';
                log('Synthetic typing injection returned:', res && res[0] && res[0].result);
            }
        } catch (err) {
            statusDiv.textContent = 'Error injecting synthetic typing.';
            log('Synthetic injection error:', err && err.message);
        }
    });

});
