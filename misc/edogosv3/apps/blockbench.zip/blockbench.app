{
    "name": "Blockbench",
    "customIcon": "spectacle-3d",
    "width": 1280,
    "height": 960,
    "html": "<!DOCTYPE html><html><head><title>Changelog</title><style>html,body{width:100%;height:100%;padding:0px;margin:0px;overflow:hidden;}iframe{width:100%;height:100%;display:block;}</style></head><body><iframe frameborder='0' src='https://web.blockbench.net'></iframe></body></html>"
}