!EDOGOSAPP 1.1
\\\CONFIG
{
    "name": "Checkers",
    "customIcon": "/usr/share/icons/16/checkers.png",
    "icon": "🖼️",
    "width": 640,
    "height": 570
}
\\\ENDCONFIG
\\\CODESTART
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="description" content="A game of checkers.">
	<title>Checkers</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link
		href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400..900;1,9..144,400..900&family=JetBrains+Mono:wght@400;600&display=swap"
		rel="stylesheet">
	<style>
    :root {
    --bg-deep: #1a1208;
    --bg-mid: #2a1d10;
    --bg-warm: #3a2818;
    --board-light: #ead7b3;
    --board-light-grain: #e0c89d;
    --board-dark: #4a2e18;
    --board-dark-grain: #3a2412;
    --board-frame: #1f1408;
    --piece-cream: #f4ead0;
    --piece-cream-shade: #c9b88a;
    --piece-cream-rim: #8a7a52;
    --piece-crimson: #8b1f1f;
    --piece-crimson-shade: #5a0e0e;
    --piece-crimson-rim: #2c0606;
    --brass: #c9a14a;
    --brass-bright: #e6c068;
    --brass-deep: #8a6a28;
    --ink: #f1e6cc;
    --ink-dim: #b8a890;
    --ink-faint: #7a6a52;
    --highlight: #f3c75a;
    --danger: #d04848;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

html,
body {
    height: 100%;
    background: var(--bg-deep);
    color: var(--ink);
    font-family: "Fraunces", Georgia, serif;
    overflow-x: hidden;
}

body {
    background:
        radial-gradient(ellipse at 20% -10%, rgba(201, 161, 74, 0.08), transparent 50%),
        radial-gradient(ellipse at 80% 110%, rgba(139, 31, 31, 0.06), transparent 50%),
        linear-gradient(180deg, var(--bg-mid) 0%, var(--bg-deep) 100%);
    min-height: 100vh;
    position: relative;
}

/* Subtle paper grain noise */
body::before {
    content: "";
    position: fixed;
    inset: 0;
    pointer-events: none;
    opacity: 0.35;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.05 0 0 0 0 0.04 0 0 0 0 0.02 0 0 0 0.5 0'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.6'/></svg>");
    mix-blend-mode: overlay;
    z-index: 0;
}

.app {
    position: relative;
    z-index: 1;
    max-width: 1200px;
    margin: 0 auto;
    padding: 32px 24px 48px;
}

main {
    display: grid;
    grid-template-columns: minmax(0, auto) 280px;
    gap: 32px;
    align-items: start;
    justify-content: center;
}

@media (max-width: 820px) {
    main {
        grid-template-columns: 1fr;
        gap: 20px;
    }
}

/* ============ BOARD ============ */
.board-shell {
    --frame: 22px;
    position: relative;
    padding: var(--frame);
    background:
        linear-gradient(135deg, #2a1808 0%, #1a0e04 50%, #2a1808 100%);
    border-radius: 8px;
    box-shadow:
        inset 0 0 0 1px rgba(201, 161, 74, 0.25),
        inset 0 0 30px rgba(0, 0, 0, 0.6),
        0 30px 60px rgba(0, 0, 0, 0.7),
        0 6px 18px rgba(0, 0, 0, 0.4);
}

.board-shell::before {
    content: "";
    position: absolute;
    inset: 8px;
    border: 1px solid rgba(201, 161, 74, 0.3);
    border-radius: 4px;
    pointer-events: none;
}

.board-coords {
    position: absolute;
    font-family: "JetBrains Mono", monospace;
    font-size: 10px;
    color: var(--brass);
    opacity: 0.55;
    letter-spacing: 0.1em;
}

.board-coords.top,
.board-coords.bottom {
    left: var(--frame);
    right: var(--frame);
    display: flex;
    justify-content: space-around;
    height: var(--frame);
    align-items: center;
}

.board-coords.top { top: 0; }
.board-coords.bottom { bottom: 0; }

.board-coords.left,
.board-coords.right {
    top: var(--frame);
    bottom: var(--frame);
    width: var(--frame);
    display: flex;
    flex-direction: column;
    justify-content: space-around;
    align-items: center;
}

.board-coords.left { left: 0; }
.board-coords.right { right: 0; }

.board {
    --size: min(72vmin, 560px);
    width: var(--size);
    height: var(--size);
    position: relative;
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    grid-template-rows: repeat(8, 1fr);
    border-radius: 2px;
    overflow: hidden;
    box-shadow: inset 0 0 0 2px rgba(0, 0, 0, 0.4);
}

.square {
    position: relative;
    cursor: default;
}

.square.light {
    background:
        radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.05), transparent 60%),
        linear-gradient(135deg, var(--board-light) 0%, var(--board-light-grain) 100%);
}

.square.dark {
    background:
        radial-gradient(circle at 70% 70%, rgba(0, 0, 0, 0.15), transparent 60%),
        linear-gradient(135deg, var(--board-dark) 0%, var(--board-dark-grain) 100%);
    cursor: pointer;
}

/* Subtle wood grain overlay on dark squares */
.square.dark::before {
    content: "";
    position: absolute;
    inset: 0;
    background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='100'><filter id='g'><feTurbulence type='turbulence' baseFrequency='0.02 0.5' numOctaves='2'/><feColorMatrix values='0 0 0 0 0.1 0 0 0 0 0.06 0 0 0 0 0.03 0 0 0 0.4 0'/></filter><rect width='100%' height='100%' filter='url(%23g)'/></svg>");
    opacity: 0.4;
    pointer-events: none;
    mix-blend-mode: multiply;
}

.square.valid-move::after {
    content: "";
    position: absolute;
    top: 50%;
    left: 50%;
    width: 22%;
    height: 22%;
    border-radius: 50%;
    background: radial-gradient(circle, var(--brass-bright) 0%, var(--brass) 60%, transparent 100%);
    transform: translate(-50%, -50%) scale(0.8);
    box-shadow: 0 0 16px rgba(230, 192, 104, 0.6);
    opacity: 0;
    animation: dotPulse 0.8s ease forwards;
    pointer-events: none;
}

@keyframes dotPulse {
    0% {
        opacity: 0;
        transform: translate(-50%, -50%) scale(0.4);
    }
    100% {
        opacity: 0.85;
        transform: translate(-50%, -50%) scale(1);
    }
}

/* Hint destination — a brass inset frame on the suggested square */
.square.hint-target {
    box-shadow:
        inset 0 0 0 2px rgba(201, 161, 74, 0.55),
        inset 0 0 14px rgba(201, 161, 74, 0.18);
}

/* ============ PIECES ============ */
.pieces-layer {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
}

.piece {
    position: absolute;
    width: 12.5%;
    height: 12.5%;
    transition: transform 0.45s cubic-bezier(0.5, 0, 0.3, 1.3), opacity 0.3s ease;
    pointer-events: auto;
    cursor: pointer;
    will-change: transform;
}

.piece-inner {
    position: absolute;
    inset: 12%;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.piece.cream .piece-inner {
    background:
        radial-gradient(circle at 35% 30%, rgba(255, 255, 255, 0.8) 0%, transparent 35%),
        radial-gradient(circle at 50% 55%, var(--piece-cream) 0%, var(--piece-cream-shade) 100%);
    box-shadow:
        inset 0 -3px 6px rgba(80, 60, 30, 0.4),
        inset 0 0 0 2px var(--piece-cream-rim),
        0 4px 8px rgba(0, 0, 0, 0.5),
        0 1px 2px rgba(0, 0, 0, 0.4);
}

.piece.crimson .piece-inner {
    background:
        radial-gradient(circle at 35% 30%, rgba(255, 200, 200, 0.4) 0%, transparent 35%),
        radial-gradient(circle at 50% 55%, var(--piece-crimson) 0%, var(--piece-crimson-shade) 100%);
    box-shadow:
        inset 0 -3px 6px rgba(20, 0, 0, 0.6),
        inset 0 0 0 2px var(--piece-crimson-rim),
        0 4px 8px rgba(0, 0, 0, 0.5),
        0 1px 2px rgba(0, 0, 0, 0.4);
}

.piece-inner::before {
    content: "";
    position: absolute;
    inset: 14%;
    border-radius: 50%;
    border: 1px dashed rgba(0, 0, 0, 0.15);
}

.piece.cream .piece-inner::before { border-color: rgba(80, 60, 30, 0.35); }
.piece.crimson .piece-inner::before { border-color: rgba(40, 0, 0, 0.4); }

/* King crown */
.piece.king .crown {
    width: 50%;
    height: 50%;
    z-index: 2;
    filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.5));
}

.piece.cream.king .crown { color: var(--brass-deep); }
.piece.crimson.king .crown { color: var(--brass-bright); }

.piece.selected { z-index: 5; }

.piece.selected .piece-inner {
    box-shadow:
        inset 0 -3px 6px rgba(80, 60, 30, 0.4),
        inset 0 0 0 2px var(--piece-cream-rim),
        0 0 0 3px var(--brass),
        0 0 24px rgba(243, 199, 90, 0.7),
        0 4px 8px rgba(0, 0, 0, 0.5);
}

.piece.crimson.selected .piece-inner {
    box-shadow:
        inset 0 -3px 6px rgba(20, 0, 0, 0.6),
        inset 0 0 0 2px var(--piece-crimson-rim),
        0 0 0 3px var(--brass),
        0 0 24px rgba(243, 199, 90, 0.7),
        0 4px 8px rgba(0, 0, 0, 0.5);
}

/* Hint piece — softer brass glow, pulsing gently. Distinct from selected. */
.piece.hint { z-index: 4; }

.piece.cream.hint .piece-inner {
    box-shadow:
        inset 0 -3px 6px rgba(80, 60, 30, 0.4),
        inset 0 0 0 2px var(--piece-cream-rim),
        0 0 0 2px rgba(201, 161, 74, 0.55),
        0 0 14px rgba(201, 161, 74, 0.35),
        0 4px 8px rgba(0, 0, 0, 0.5);
    animation: hintPulse 2.4s ease-in-out infinite;
}

@keyframes hintPulse {
    0%, 100% { filter: brightness(1); }
    50%      { filter: brightness(1.12); }
}

.piece.captured {
    opacity: 0;
    transform-origin: center;
    animation: capture 0.4s ease forwards;
    pointer-events: none;
}

@keyframes capture {
    0%   { opacity: 1; }
    50%  { opacity: 0.6; }
    100% { opacity: 0; }
}

.piece.promoting .piece-inner {
    animation: promote 0.6s ease;
}

@keyframes promote {
    0%, 100% { transform: scale(1); }
    50%      { transform: scale(1.25); box-shadow: 0 0 30px var(--brass-bright); }
}

/* ============ PANEL ============ */
.panel {
    background:
        linear-gradient(180deg, rgba(58, 40, 24, 0.7) 0%, rgba(42, 29, 16, 0.7) 100%);
    border: 1px solid rgba(201, 161, 74, 0.2);
    border-radius: 6px;
    padding: 22px 22px 20px;
    backdrop-filter: blur(8px);
    box-shadow:
        inset 0 1px 0 rgba(255, 230, 180, 0.05),
        0 12px 30px rgba(0, 0, 0, 0.4);
}

.panel-title {
    font-family: "JetBrains Mono", monospace;
    font-size: 10px;
    letter-spacing: 0.25em;
    color: var(--brass);
    text-transform: uppercase;
    margin-bottom: 8px;
    opacity: 0.85;
}

.status {
    font-family: "Fraunces", serif;
    font-style: italic;
    font-size: 22px;
    line-height: 1.25;
    color: var(--ink);
    min-height: 56px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid rgba(201, 161, 74, 0.15);
    padding-bottom: 16px;
    margin-bottom: 18px;
}

.thinking::after {
    content: "";
    display: inline-block;
    width: 6px;
    height: 6px;
    margin-left: 8px;
    border-radius: 50%;
    background: var(--brass);
    animation: dots 1.2s infinite;
}

@keyframes dots {
    0%, 80%, 100% { opacity: 0.3; transform: scale(0.8); }
    40%           { opacity: 1;   transform: scale(1.2); }
}

.captures {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    margin-bottom: 22px;
}

.capture-card {
    padding: 10px 12px;
    background: rgba(0, 0, 0, 0.25);
    border-radius: 4px;
    border: 1px solid rgba(201, 161, 74, 0.1);
}

.capture-label {
    font-family: "JetBrains Mono", monospace;
    font-size: 9px;
    letter-spacing: 0.2em;
    color: var(--ink-faint);
    text-transform: uppercase;
    margin-bottom: 4px;
}

.capture-value {
    font-family: "Fraunces", serif;
    font-weight: 600;
    font-size: 28px;
    color: var(--ink);
    line-height: 1;
}

.capture-card.you .capture-value  { color: var(--piece-cream); }
.capture-card.them .capture-value { color: #d96a6a; }

.difficulty { margin-bottom: 22px; }

.pill-group {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 4px;
    background: rgba(0, 0, 0, 0.3);
    padding: 4px;
    border-radius: 4px;
    border: 1px solid rgba(201, 161, 74, 0.1);
}

.pill {
    appearance: none;
    background: transparent;
    border: none;
    color: var(--ink-dim);
    font-family: "Fraunces", serif;
    font-size: 14px;
    font-weight: 500;
    letter-spacing: 0.04em;
    padding: 9px 8px;
    border-radius: 3px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.pill:hover { color: var(--ink); }

.pill.active {
    background: linear-gradient(180deg, var(--brass) 0%, var(--brass-deep) 100%);
    color: var(--bg-deep);
    font-weight: 600;
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.15) inset, 0 2px 4px rgba(0, 0, 0, 0.3);
}

/* ============ HINTS TOGGLE ============ */
.hints-toggle {
    margin-bottom: 22px;
}

.check-row {
    display: flex;
    align-items: center;
    gap: 12px;
    cursor: pointer;
    padding: 10px 12px;
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(201, 161, 74, 0.1);
    border-radius: 4px;
    transition: border-color 0.2s ease, background 0.2s ease;
    user-select: none;
}

.check-row:hover {
    border-color: rgba(201, 161, 74, 0.3);
}

.check-row input[type="checkbox"] {
    position: absolute;
    width: 1px;
    height: 1px;
    opacity: 0;
    pointer-events: none;
}

.check-mark {
    width: 18px;
    height: 18px;
    border: 1px solid rgba(201, 161, 74, 0.4);
    border-radius: 3px;
    background: rgba(0, 0, 0, 0.35);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    transition: all 0.18s ease;
    position: relative;
}

.check-row input:checked + .check-mark {
    background: linear-gradient(180deg, var(--brass) 0%, var(--brass-deep) 100%);
    border-color: var(--brass-deep);
    box-shadow: 0 1px 0 rgba(255, 255, 255, 0.15) inset, 0 1px 3px rgba(0, 0, 0, 0.3);
}

.check-row input:checked + .check-mark::after {
    content: "";
    width: 5px;
    height: 9px;
    border: solid var(--bg-deep);
    border-width: 0 2px 2px 0;
    transform: translateY(-1px) rotate(45deg);
}

.check-row input:focus-visible + .check-mark {
    outline: 2px solid var(--brass-bright);
    outline-offset: 2px;
}

.check-text {
    font-family: "Fraunces", serif;
    font-size: 14px;
    color: var(--ink-dim);
    letter-spacing: 0.04em;
    transition: color 0.18s ease;
}

.check-row input:checked ~ .check-text {
    color: var(--ink);
}

/* ============ NEW GAME BUTTON ============ */
.new-game {
    width: 100%;
    appearance: none;
    background:
        linear-gradient(180deg, var(--piece-crimson) 0%, var(--piece-crimson-shade) 100%);
    color: var(--ink);
    border: 1px solid var(--piece-crimson-rim);
    border-radius: 4px;
    padding: 13px 18px;
    font-family: "Fraunces", serif;
    font-size: 16px;
    font-weight: 500;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow:
        inset 0 1px 0 rgba(255, 200, 200, 0.2),
        0 4px 10px rgba(0, 0, 0, 0.4);
}

.new-game:hover {
    transform: translateY(-1px);
    box-shadow:
        inset 0 1px 0 rgba(255, 200, 200, 0.25),
        0 6px 14px rgba(0, 0, 0, 0.5);
}

.new-game:active { transform: translateY(0); }

/* ============ MODAL ============ */
.modal-backdrop {
    position: fixed;
    inset: 0;
    background: rgba(10, 5, 0, 0.78);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 100;
    backdrop-filter: blur(6px);
}

.modal-backdrop.show {
    display: flex;
    animation: fadeIn 0.4s ease;
}

@keyframes fadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
}

.modal {
    background: linear-gradient(180deg, var(--bg-warm) 0%, var(--bg-mid) 100%);
    border: 1px solid rgba(201, 161, 74, 0.3);
    border-radius: 8px;
    padding: 36px 42px 32px;
    max-width: 420px;
    text-align: center;
    box-shadow: 0 30px 80px rgba(0, 0, 0, 0.7);
    animation: rise 0.5s cubic-bezier(0.2, 0.8, 0.3, 1.2);
}

@keyframes rise {
    from { transform: translateY(30px); opacity: 0; }
    to   { transform: translateY(0);    opacity: 1; }
}

.modal-decor {
    color: var(--brass);
    letter-spacing: 0.5em;
    font-size: 14px;
    opacity: 0.7;
    margin-bottom: 14px;
}

.modal-title {
    font-family: "Fraunces", serif;
    font-size: 38px;
    font-weight: 600;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    color: var(--ink);
    margin-bottom: 14px;
    line-height: 1.05;
}

.modal-message {
    font-family: "Fraunces", serif;
    font-style: italic;
    font-size: 17px;
    color: var(--ink-dim);
    margin-bottom: 28px;
    line-height: 1.5;
}

.modal-buttons {
    display: flex;
    gap: 10px;
    justify-content: center;
}

.modal-buttons button {
    flex: 1;
    appearance: none;
    border: 1px solid rgba(201, 161, 74, 0.3);
    background: rgba(0, 0, 0, 0.3);
    color: var(--ink);
    padding: 12px 20px;
    border-radius: 4px;
    font-family: "Fraunces", serif;
    font-size: 14px;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    cursor: pointer;
    transition: all 0.2s ease;
}

.modal-buttons button:hover {
    background: rgba(201, 161, 74, 0.15);
    border-color: var(--brass);
}

.modal-buttons button.primary {
    background: linear-gradient(180deg, var(--brass) 0%, var(--brass-deep) 100%);
    color: var(--bg-deep);
    font-weight: 600;
    border-color: var(--brass-deep);
}
    </style>
</head>

<body>
	<div class="app">
		<main>
			<div class="board-shell">
				<div class="board-coords top">
					<span>a</span><span>b</span><span>c</span><span>d</span>
					<span>e</span><span>f</span><span>g</span><span>h</span>
				</div>
				<div class="board-coords bottom">
					<span>a</span><span>b</span><span>c</span><span>d</span>
					<span>e</span><span>f</span><span>g</span><span>h</span>
				</div>
				<div class="board-coords left">
					<span>8</span><span>7</span><span>6</span><span>5</span>
					<span>4</span><span>3</span><span>2</span><span>1</span>
				</div>
				<div class="board-coords right">
					<span>8</span><span>7</span><span>6</span><span>5</span>
					<span>4</span><span>3</span><span>2</span><span>1</span>
				</div>
				<div class="board" id="board">
					<!-- 64 squares injected here -->
					<div class="pieces-layer" id="pieces-layer"></div>
				</div>
			</div>

			<aside class="panel">
				<div class="panel-title">Status</div>
				<div class="status" id="status">Your move.</div>

				<div class="captures">
					<div class="capture-card you">
						<div class="capture-label">You took</div>
						<div class="capture-value" id="you-took">0</div>
					</div>
					<div class="capture-card them">
						<div class="capture-label">They took</div>
						<div class="capture-value" id="they-took">0</div>
					</div>
				</div>

				<div class="difficulty">
					<div class="panel-title">Difficulty</div>
					<div class="pill-group" role="tablist" id="difficulty-group">
						<button class="pill active" data-level="easy">Easy</button>
						<button class="pill" data-level="medium">Medium</button>
						<button class="pill" data-level="hard">Hard</button>
					</div>
				</div>

				<div class="hints-toggle">
					<label class="check-row">
						<input type="checkbox" id="hints-checkbox" />
						<span class="check-mark"></span>
						<span class="check-text">Show hints</span>
					</label>
				</div>

				<button class="new-game" id="new-game">New Game</button>
			</aside>
		</main>
	</div>

	<div class="modal-backdrop" id="modal">
		<div class="modal">
			<div class="modal-decor">❦ · ❦</div>
			<div class="modal-title" id="modal-title">Game Over</div>
			<div class="modal-message" id="modal-message">…</div>
			<div class="modal-buttons">
				<button id="modal-rematch" class="primary">Rematch</button>
				<button id="modal-close">Close</button>
			</div>
		</div>
	</div>

	<svg style="display:none" xmlns="http://www.w3.org/2000/svg">
		<symbol id="crown" viewBox="0 0 24 24">
			<!-- Five-pointed crown shape -->
			<path d="M3 18 L4 8 L8 12 L12 6 L16 12 L20 8 L21 18 Z" fill="currentColor" stroke="rgba(0,0,0,0.4)"
				stroke-width="0.6" stroke-linejoin="round" />
			<rect x="4" y="18" width="16" height="2" rx="0.5" fill="currentColor" stroke="rgba(0,0,0,0.4)"
				stroke-width="0.6" />
			<circle cx="4" cy="8" r="1" fill="currentColor" />
			<circle cx="12" cy="6" r="1" fill="currentColor" />
			<circle cx="20" cy="8" r="1" fill="currentColor" />
		</symbol>
	</svg>

	<script>
		// Piece codes
		const EMPTY = 0;
		const CREAM = 1;       // Player (bottom, moves up)
		const CRIMSON = 2;     // AI (top, moves down)
		const CREAM_K = 3;
		const CRIMSON_K = 4;

		// Side helpers
		const sideOf = p =>
			(p === CREAM || p === CREAM_K) ? 1 :
				(p === CRIMSON || p === CRIMSON_K) ? 2 : 0;
		const isKing = p => p === CREAM_K || p === CRIMSON_K;
		const inB = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;

		const dirsOf = p => {
			if (p === CREAM) return [[-1, -1], [-1, 1]];
			if (p === CRIMSON) return [[1, -1], [1, 1]];
			if (p === CREAM_K || p === CRIMSON_K) return [[-1, -1], [-1, 1], [1, -1], [1, 1]];
			return [];
		};

		function newBoard() {
			const b = Array.from({ length: 8 }, () => Array(8).fill(EMPTY));
			for (let r = 0; r < 3; r++)
				for (let c = 0; c < 8; c++)
					if ((r + c) % 2 === 1) b[r][c] = CRIMSON;
			for (let r = 5; r < 8; r++)
				for (let c = 0; c < 8; c++)
					if ((r + c) % 2 === 1) b[r][c] = CREAM;
			return b;
		}

		// ---------- Move generation ----------
		// Move: { from:[r,c], to:[r,c], path:[[r,c],...], captured:[[r,c],...] }

		function getJumpsForPiece(board, sr, sc) {
			const startPiece = board[sr][sc];
			if (!startPiece) return [];
			const side = sideOf(startPiece);
			const results = [];

			function explore(state, r, c, piece, path, captured) {
				for (const [dr, dc] of dirsOf(piece)) {
					const mr = r + dr, mc = c + dc;
					const lr = r + 2 * dr, lc = c + 2 * dc;
					if (!inB(lr, lc)) continue;
					const mp = state[mr][mc];
					if (!mp || sideOf(mp) === side) continue;
					if (state[lr][lc] !== EMPTY) continue;
					if (captured.some(([cr, cc]) => cr === mr && cc === mc)) continue;

					const ns = state.map(row => row.slice());
					ns[r][c] = EMPTY;
					ns[mr][mc] = EMPTY;
					let np = piece;
					let promoted = false;
					if (piece === CREAM && lr === 0) { np = CREAM_K; promoted = true; }
					if (piece === CRIMSON && lr === 7) { np = CRIMSON_K; promoted = true; }
					ns[lr][lc] = np;

					const newPath = [...path, [lr, lc]];
					const newCap = [...captured, [mr, mc]];

					if (promoted) {
						// American checkers: stop on king-promotion mid-jump
						results.push({ from: [sr, sc], to: [lr, lc], path: newPath, captured: newCap, promoted: true });
					} else {
						const before = results.length;
						explore(ns, lr, lc, np, newPath, newCap);
						if (results.length === before) {
							results.push({ from: [sr, sc], to: [lr, lc], path: newPath, captured: newCap, promoted: false });
						}
					}
				}
			}

			explore(board, sr, sc, startPiece, [[sr, sc]], []);
			return results;
		}

		function getSimpleMovesForPiece(board, r, c) {
			const piece = board[r][c];
			if (!piece) return [];
			const out = [];
			for (const [dr, dc] of dirsOf(piece)) {
				const nr = r + dr, nc = c + dc;
				if (!inB(nr, nc)) continue;
				if (board[nr][nc] !== EMPTY) continue;
				let promoted = false;
				if (piece === CREAM && nr === 0) promoted = true;
				if (piece === CRIMSON && nr === 7) promoted = true;
				out.push({ from: [r, c], to: [nr, nc], path: [[r, c], [nr, nc]], captured: [], promoted });
			}
			return out;
		}

		// All legal moves for a side. The AI search uses standard checkers rules
		// (forced jumps), the player UI uses { forceJumps: false } for free play.
		function getAllMoves(board, side, opts) {
			const forceJumps = opts && opts.forceJumps === false ? false : true;

			const jumps = [];
			for (let r = 0; r < 8; r++)
				for (let c = 0; c < 8; c++)
					if (sideOf(board[r][c]) === side)
						jumps.push(...getJumpsForPiece(board, r, c));

			if (forceJumps && jumps.length > 0) {
				return { moves: jumps, mustJump: true };
			}

			const simples = [];
			for (let r = 0; r < 8; r++)
				for (let c = 0; c < 8; c++)
					if (sideOf(board[r][c]) === side)
						simples.push(...getSimpleMovesForPiece(board, r, c));

			return { moves: [...jumps, ...simples], mustJump: false };
		}

		function applyMove(board, move) {
			const nb = board.map(row => row.slice());
			const [sr, sc] = move.from;
			const [er, ec] = move.to;
			let piece = nb[sr][sc];
			nb[sr][sc] = EMPTY;
			for (const [cr, cc] of move.captured) nb[cr][cc] = EMPTY;
			if (piece === CREAM && er === 0) piece = CREAM_K;
			if (piece === CRIMSON && er === 7) piece = CRIMSON_K;
			nb[er][ec] = piece;
			return nb;
		}

		// ---------- AI ----------
		// Maximize for CRIMSON (AI = side 2). Positive = good for AI.

		function evaluate(board) {
			let score = 0;
			for (let r = 0; r < 8; r++) {
				for (let c = 0; c < 8; c++) {
					const p = board[r][c];
					if (!p) continue;
					const centerDist = Math.abs(c - 3.5) + Math.abs(r - 3.5);
					const centerBonus = (7 - centerDist) * 0.15;
					if (p === CRIMSON) score += 10 + r * 0.4 + centerBonus;
					else if (p === CRIMSON_K) score += 16 + centerBonus;
					else if (p === CREAM) score -= 10 + (7 - r) * 0.4 + centerBonus;
					else if (p === CREAM_K) score -= 16 + centerBonus;
				}
			}
			return score;
		}

		function minimax(board, depth, alpha, beta, maximizing) {
			const side = maximizing ? 2 : 1;
			const { moves } = getAllMoves(board, side);
			if (moves.length === 0) {
				return maximizing ? -100000 + (10 - depth) : 100000 - (10 - depth);
			}
			if (depth === 0) return evaluate(board);

			if (maximizing) {
				let best = -Infinity;
				for (const m of moves) {
					const nb = applyMove(board, m);
					const v = minimax(nb, depth - 1, alpha, beta, false);
					if (v > best) best = v;
					if (best > alpha) alpha = best;
					if (beta <= alpha) break;
				}
				return best;
			} else {
				let best = Infinity;
				for (const m of moves) {
					const nb = applyMove(board, m);
					const v = minimax(nb, depth - 1, alpha, beta, true);
					if (v < best) best = v;
					if (best < beta) beta = best;
					if (beta <= alpha) break;
				}
				return best;
			}
		}

		function pickAIMove(board, difficulty) {
			const { moves } = getAllMoves(board, 2);
			if (moves.length === 0) return null;

			if (difficulty === 'easy') {
				if (Math.random() < 0.8) {
					return moves[Math.floor(Math.random() * moves.length)];
				}
				let best = -Infinity, bestMove = moves[0];
				for (const m of moves) {
					const v = evaluate(applyMove(board, m));
					if (v > best) { best = v; bestMove = m; }
				}
				return bestMove;
			}

			const depth = difficulty === 'medium' ? 4 : 7;
			const shuffled = moves.slice().sort(() => Math.random() - 0.5);

			let bestMove = shuffled[0];
			let bestVal = -Infinity;
			let alpha = -Infinity, beta = Infinity;
			for (const m of shuffled) {
				const nb = applyMove(board, m);
				const v = minimax(nb, depth - 1, alpha, beta, false);
				if (v > bestVal) { bestVal = v; bestMove = m; }
				if (v > alpha) alpha = v;
			}
			return bestMove;
		}

		// Pick the move a strong player would make for the player's side (used for hints).
		// Searches at depth 4 — fast and gives sound suggestions.
		function pickHintMove(board) {
			const { moves } = getAllMoves(board, 1, { forceJumps: false });
			if (moves.length === 0) return null;
			if (moves.length === 1) return moves[0];

			let bestMove = moves[0];
			let bestVal = Infinity;
			let alpha = -Infinity, beta = Infinity;
			const shuffled = moves.slice().sort(() => Math.random() - 0.5);
			for (const m of shuffled) {
				const nb = applyMove(board, m);
				// AI moves next — maximizing.
				const v = minimax(nb, 4, alpha, beta, true);
				if (v < bestVal) { bestVal = v; bestMove = m; }
				if (v < beta) beta = v;
			}
			return bestMove;
		}

		/* =========================================================================
		   UI
		   ========================================================================= */

		const boardEl = document.getElementById('board');
		const piecesLayer = document.getElementById('pieces-layer');
		const statusEl = document.getElementById('status');
		const youTookEl = document.getElementById('you-took');
		const theyTookEl = document.getElementById('they-took');
		const newGameBtn = document.getElementById('new-game');
		const diffGroup = document.getElementById('difficulty-group');
		const hintsCheckbox = document.getElementById('hints-checkbox');
		const modal = document.getElementById('modal');
		const modalTitle = document.getElementById('modal-title');
		const modalMsg = document.getElementById('modal-message');
		const modalRematchBtn = document.getElementById('modal-rematch');
		const modalCloseBtn = document.getElementById('modal-close');

		// State
		let board = newBoard();
		let turn = 1;
		let difficulty = 'easy';
		let selected = null;
		let validMoves = [];
		let captures = { you: 0, them: 0 };
		let busy = false;
		let gameOver = false;
		let pieceIds = {};
		let pieceSeq = 0;

		// Hint state
		let hintsEnabled = false;
		let currentHint = null;

		// ---------- Build squares ----------
		function buildSquares() {
			const layer = piecesLayer;
			boardEl.innerHTML = '';
			for (let r = 0; r < 8; r++) {
				for (let c = 0; c < 8; c++) {
					const sq = document.createElement('div');
					sq.className = 'square ' + ((r + c) % 2 === 0 ? 'light' : 'dark');
					sq.dataset.r = r;
					sq.dataset.c = c;
					sq.addEventListener('click', () => onSquareClick(r, c));
					boardEl.appendChild(sq);
				}
			}
			boardEl.appendChild(layer);
		}

		// ---------- Pieces ----------
		function rebuildPieces() {
			piecesLayer.innerHTML = '';
			pieceIds = {};

			for (let r = 0; r < 8; r++) {
				for (let c = 0; c < 8; c++) {
					const p = board[r][c];
					if (!p) continue;
					const el = document.createElement('div');
					const id = 'p' + (++pieceSeq);
					el.id = id;
					el.className = 'piece ' + (sideOf(p) === 1 ? 'cream' : 'crimson') + (isKing(p) ? ' king' : '');
					el.style.transform = `translate(${c * 100}%, ${r * 100}%)`;

					const inner = document.createElement('div');
					inner.className = 'piece-inner';
					el.appendChild(inner);

					if (isKing(p)) {
						inner.appendChild(makeCrown());
					}

					const pr = r, pc = c;
					el.addEventListener('click', e => {
						e.stopPropagation();
						onPieceClick(pr, pc);
					});

					piecesLayer.appendChild(el);
					pieceIds[r + ',' + c] = id;
				}
			}
		}

		function makeCrown() {
			const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
			svg.setAttribute('class', 'crown');
			svg.setAttribute('viewBox', '0 0 24 24');
			const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
			use.setAttribute('href', '#crown');
			svg.appendChild(use);
			return svg;
		}

		// Animate a move along its path; fade captured pieces.
		async function animateMove(move) {
			const fromKey = move.from[0] + ',' + move.from[1];
			const id = pieceIds[fromKey];
			const el = id ? document.getElementById(id) : null;
			if (!el) return;

			for (let i = 1; i < move.path.length; i++) {
				const [r, c] = move.path[i];
				el.style.transform = `translate(${c * 100}%, ${r * 100}%)`;
				if (move.captured.length) {
					const captured = move.captured[i - 1];
					if (captured) {
						const ck = captured[0] + ',' + captured[1];
						const cid = pieceIds[ck];
						const cel = cid ? document.getElementById(cid) : null;
						if (cel) {
							setTimeout(() => cel.classList.add('captured'), 180);
							setTimeout(() => cel.remove(), 600);
						}
					}
				}
				await wait(450);
			}

			if (move.promoted) {
				el.classList.add('king', 'promoting');
				const inner = el.querySelector('.piece-inner');
				if (inner && !inner.querySelector('.crown')) {
					inner.appendChild(makeCrown());
				}
				setTimeout(() => el.classList.remove('promoting'), 700);
			}
		}

		const wait = ms => new Promise(r => setTimeout(r, ms));

		// ---------- Click handling ----------
		function onPieceClick(r, c) {
			if (busy || gameOver) return;
			if (turn !== 1) return;
			const p = board[r][c];
			if (sideOf(p) !== 1) {
				onSquareClick(r, c);
				return;
			}
			selectPiece(r, c);
		}

		function onSquareClick(r, c) {
			if (busy || gameOver) return;
			if (turn !== 1) return;
			if (!selected) return;
			const move = validMoves.find(m => m.to[0] === r && m.to[1] === c);
			if (move) {
				executePlayerMove(move);
			} else {
				const p = board[r][c];
				if (sideOf(p) === 1) selectPiece(r, c);
				else clearSelection();
			}
		}

		// Player can move ANY of their pieces — no forced-jump enforcement.
		function selectPiece(r, c) {
			const movesForThis = [
				...getJumpsForPiece(board, r, c),
				...getSimpleMovesForPiece(board, r, c)
			];
			if (movesForThis.length === 0) {
				flashStatus("That piece has no moves.");
				return;
			}
			selected = [r, c];
			validMoves = movesForThis;
			refreshHighlights();
		}

		function clearSelection() {
			selected = null;
			validMoves = [];
			refreshHighlights();
		}

		function refreshHighlights() {
			for (const sq of boardEl.querySelectorAll('.square')) {
				sq.classList.remove('valid-move', 'hint-target');
			}
			for (const pe of piecesLayer.querySelectorAll('.piece')) {
				pe.classList.remove('selected', 'hint');
			}

			// Show hint when nothing is selected and it's the player's move.
			if (hintsEnabled && !gameOver && turn === 1 && !selected && currentHint) {
				const [hr, hc] = currentHint.from;
				const [tr, tc] = currentHint.to;
				const id = pieceIds[hr + ',' + hc];
				const el = id ? document.getElementById(id) : null;
				if (el) el.classList.add('hint');
				const sq = squareAt(tr, tc);
				if (sq) sq.classList.add('hint-target');
			}

			if (selected) {
				const [r, c] = selected;
				const id = pieceIds[r + ',' + c];
				const el = id ? document.getElementById(id) : null;
				if (el) el.classList.add('selected');
				for (const m of validMoves) {
					const [tr, tc] = m.to;
					const sq = squareAt(tr, tc);
					if (sq) sq.classList.add('valid-move');
				}
			}
		}

		function squareAt(r, c) {
			return boardEl.querySelector(`.square[data-r="${r}"][data-c="${c}"]`);
		}

		// ---------- Move execution ----------
		async function executePlayerMove(move) {
			busy = true;
			clearSelection();
			currentHint = null; // hint is stale after a move
			if (move.captured.length) captures.you += move.captured.length;
			await animateMoveAndApply(move);
			refreshCaptures();
			if (checkGameOver()) return;
			turn = 2;
			setStatus("Computer is thinking", true);
			busy = false;
			setTimeout(runAIMove, 350);
		}

		async function animateMoveAndApply(move) {
			await animateMove(move);
			board = applyMove(board, move);
			rebuildPieces();
		}

		async function runAIMove() {
			if (gameOver) return;
			busy = true;
			await wait(80);
			let move = null;
			try {
				move = pickAIMove(board, difficulty);
			} catch (e) {
				console.error(e);
			}
			if (!move) {
				return endGame('player', "Your opponent is out of moves. You win.");
			}
			if (move.captured.length) captures.them += move.captured.length;
			await animateMoveAndApply(move);
			refreshCaptures();
			if (checkGameOver()) return;
			turn = 1;
			setStatus("Your move.");
			busy = false;
			refreshHighlights();
			// Compute hint async so the UI stays responsive — clicks land
			// immediately, and the hint glow appears a moment later.
			setTimeout(() => {
				if (turn !== 1 || gameOver || selected) return;
				recomputeHint();
				refreshHighlights();
			}, 30);
		}

		// ---------- Hint computation ----------
		function recomputeHint() {
			if (!hintsEnabled || gameOver || turn !== 1) {
				currentHint = null;
				return;
			}
			try {
				currentHint = pickHintMove(board);
			} catch (e) {
				console.error(e);
				currentHint = null;
			}
		}

		// ---------- Game-over checks ----------
		function checkGameOver() {
			const nextSide = (turn === 1) ? 2 : 1;
			const all = getAllMoves(board, nextSide);
			let creamCount = 0, crimsonCount = 0;
			for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
				if (sideOf(board[r][c]) === 1) creamCount++;
				else if (sideOf(board[r][c]) === 2) crimsonCount++;
			}
			if (creamCount === 0) return endGame('ai', "The computer wins.");
			if (crimsonCount === 0) return endGame('player', "You've cleared the board. Victory.");
			if (all.moves.length === 0) {
				if (nextSide === 1) return endGame('ai', "You have no moves. Computer wins.");
				else return endGame('player', "Computer has no moves. You win.");
			}
			return false;
		}

		function endGame(winner, message) {
			gameOver = true;
			busy = true;
			currentHint = null;
			if (winner === 'player') {
				setStatus("You won.");
				showModal("Victory", message + flairFor(winner));
			} else {
				setStatus("You lost.");
				showModal("Defeat", message + flairFor(winner));
			}
			return true;
		}

		function flairFor(winner) {
			if (winner === 'player') {
				const lines = [
					"",
					" Nice one.",
					" You are the checkers master.",
					" Impressive."
				];
				return lines[Math.floor(Math.random() * lines.length)];
			} else {
				if (difficulty === 'hard') {
					const lines = [
						" Try Medium - you might not lose then.",
						" This difficulty is just unfair, isn't it.",
						" Maybe a difficulty level down?"
					];
					return lines[Math.floor(Math.random() * lines.length)];
				} else if (difficulty === 'medium') {
					return " Ouch.";
				} else {
					return " Easy beat you. Awkward.";
				}
			}
		}

		// ---------- Status / UI helpers ----------
		function setStatus(text, thinking = false) {
			statusEl.textContent = text;
			statusEl.classList.toggle('thinking', thinking);
		}

		let flashTimeout = null;
		function flashStatus(msg) {
			setStatus(msg);
			clearTimeout(flashTimeout);
			flashTimeout = setTimeout(() => {
				if (turn === 1 && !gameOver) setStatus("Your move.");
			}, 1800);
		}

		function refreshCaptures() {
			youTookEl.textContent = captures.you;
			theyTookEl.textContent = captures.them;
		}

		function showModal(title, message) {
			modalTitle.textContent = title;
			modalMsg.textContent = message;
			modal.classList.add('show');
		}
		function hideModal() { modal.classList.remove('show'); }

		// ---------- Difficulty controls ----------
		diffGroup.addEventListener('click', e => {
			const btn = e.target.closest('.pill');
			if (!btn) return;
			for (const b of diffGroup.querySelectorAll('.pill')) b.classList.toggle('active', b === btn);
			difficulty = btn.dataset.level;
		});

		// ---------- Hints toggle ----------
		hintsCheckbox.addEventListener('change', () => {
			hintsEnabled = hintsCheckbox.checked;
			recomputeHint();
			refreshHighlights();
		});

		// ---------- New game ----------
		function startNewGame() {
			board = newBoard();
			turn = 1;
			selected = null;
			validMoves = [];
			captures = { you: 0, them: 0 };
			busy = false;
			gameOver = false;
			currentHint = null;
			hideModal();
			buildSquares();
			rebuildPieces();
			refreshCaptures();
			setStatus("Your move.");
			recomputeHint();
			refreshHighlights();
		}

		newGameBtn.addEventListener('click', startNewGame);
		modalRematchBtn.addEventListener('click', startNewGame);
		modalCloseBtn.addEventListener('click', hideModal);

		// Boot
		startNewGame();
	</script>
</body>

</html>
\\\CODEEND
