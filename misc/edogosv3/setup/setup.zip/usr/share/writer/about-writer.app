{
    "name": "About Writer",
    "customIcon": "information",
    "width": 200,
    "height": 150,
    "html": "<!DOCTYPE html> <html> <head> <title>About Writer</title> <style> body { text-align: center; background-color: (rgb(225, 225, 225)); font-family: Arial, Helvetica, sans-serif; } </style> </head> <body> <h2>Writer 1.0</h2> </body> </html>"
}
