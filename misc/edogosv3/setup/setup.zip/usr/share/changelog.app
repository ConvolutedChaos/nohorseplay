{
    "name": "Changelog",
    "customIcon": "information",
    "width": 500,
    "height": 400,
    "html": "<!DOCTYPE html><html><head><title>Changelog</title><style>html,body{width:100%;height:100%;padding:0px;margin:0px;overflow:hidden;}iframe{width:100%;height:100%;display:block;}</style></head><body><iframe frameborder='0' src='/misc/edogosv3/changelog.html'>Demo App.</iframe></body></html>"
}
