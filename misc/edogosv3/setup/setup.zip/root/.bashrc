# fake root bashrc
