Hey, thanks for using E-Dog OS!
Just a few notes before you start:

1) the files and folders you add should persist across reloads. In other words, you can reload the page and your files will stay.

2) If the page is slow on folders with lots of files, don't worry, that's normal.

3) This is a work in progress, so some features may be incomplete.