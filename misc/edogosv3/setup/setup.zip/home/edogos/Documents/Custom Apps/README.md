# Creating Custom Apps for E-Dog OS

Now, with E-Dog OS, you can create your own apps!

For something basic like a calculator, you just need HTML. But if your app needs to read or write files, you can also use the built-in **Filesystem API** — more on that below.
You can also use **OS-level** functions, like functions to throw an error, get the version, etc. More on that below also.

---

## Getting Started

1. **Make a new file.** Name it whatever you want, but make sure it has the extension: **`.app`**
   If it doesn't have the extension, E-Dog OS won't know that it's a custom app.

2. **Right-click the file, click "Open With," and click "Text Editor."** Now you can start writing code for the app!

Start with some curly braces. These can be found on the right side of your keyboard, near the Backspace and Enter keys.

```
{ App code goes here! }
```

The app needs the attributes: **name**, **icon**, **width**, **height**, and **html**.

- **html** is the app's actual code. Everything else is info about the app and how it should be rendered.
- **Tip:** "icon" can be replaced with "customIcon", but instead of any text, you need to specify something like "box". If it's not in the icon database, then it will not work. The icon database can be found in the folder of this text document.

### Example App

```json
{
    "name": "Example App",
    "customIcon": "gear",
    "width": 300,
    "height": 200,
    "html": "<p>Demo App.</p>"
}
```

### Watch Out for Quotes!

You can't use double quotes inside of double quotes.

**Right:**
```json
"html": "<p title='Demo App'>Demo App.</p>"
```

**Wrong:**
```json
"html": "<p title="Demo App">Demo App.</p>"
```

---

## Filesystem API

Your custom apps can interact with the E-Dog OS filesystem! Every custom app automatically has access to a global **`fs`** object with the following functions. All of them are **async**, so use `await` when calling them.

### User Paths

You don't need to code your own username into file paths. There are three ways to reference the current user's home folder:

**Use `~` (recommended).** Just like the terminal, `~` expands to the current user's home folder automatically:
```js
await fs.readFile('~/Documents/notes.txt');
await fs.writeFile('~/Documents/notes.txt', 'hello');
await fs.listDir('~/Pictures');
```

**Use `fs.home`.** This is a string containing the full path to the user's home folder:
```js
await fs.readFile(fs.home + '/Documents/notes.txt');
// same as '~/Documents/notes.txt'
```

**Use `fs.username`.** This is just the username string, in case you need to build a path yourself:
```js
await fs.listDir('/home/' + fs.username + '/Documents');
```

### fs.readFile(path)

Reads a file and returns its contents.

```js
const file = await fs.readFile('~/Documents/notes.txt');
console.log(file.text);  // the file's text content
console.log(file.name);  // "notes.txt"
console.log(file.size);  // size in bytes
console.log(file.mime);  // MIME type, if known
```

For binary files (images, etc.), `file.text` will be `null` and `file.base64` will contain the data as a Base64-encoded string.

### fs.writeFile(path, text)

Creates or overwrites a file with the given text content.

```js
await fs.writeFile('~/Documents/hello.txt', 'Hello from my app!');
```

If the file already exists, it will be overwritten. If it doesn't exist, it will be created. Any missing folders in the path will also be created automatically.

### fs.listDir(path)

Lists the contents of a folder. Returns an array of objects.

```js
const items = await fs.listDir('~/Documents');
// items = [
//   { name: "hello.txt", type: "file", size: 18, mime: "" },
//   { name: "Photos", type: "folder", size: 0, mime: "" },
// ]
```

### fs.mkdir(path)

Creates a folder. Missing parent folders are created automatically.

```js
await fs.mkdir('~/Documents/MyAppData');
```

### fs.delete(path)

Deletes a file or folder. If it's a folder, everything inside it is deleted too.

```js
await fs.delete('~/Documents/old-file.txt');
```

### fs.exists(path)

Checks whether a file or folder exists.

```js
const result = await fs.exists('~/Documents/notes.txt');
// result = { exists: true, type: "file" }
```

---

## Full Example: A Simple Notes App

```json
{
    "name": "Quick Notes",
    "customIcon": "notepad",
    "width": 500,
    "height": 400,
    "html": "<div style='font-family: sans-serif; padding: 16px; color: white; display: flex; flex-direction: column; height: 100%; box-sizing: border-box;'><h2 style='margin:0 0 8px 0;'>Quick Notes</h2><textarea id='editor' style='flex:1; background:#1e1e1e; color:#d4d4d4; border:1px solid #444; padding:10px; font-size:14px; resize:none;'></textarea><div style='margin-top:8px; display:flex; gap:8px;'><button onclick='save()' style='padding:6px 16px; cursor:pointer;'>Save</button><button onclick='load()' style='padding:6px 16px; cursor:pointer;'>Load</button><span id='status' style='color:#888; font-size:12px; align-self:center;'></span></div></div><script>const PATH = '~/Documents/quicknotes.txt'; async function save() { await fs.writeFile(PATH, document.getElementById('editor').value); document.getElementById('status').textContent = 'Saved!'; setTimeout(() => document.getElementById('status').textContent = '', 2000); } async function load() { try { const file = await fs.readFile(PATH); document.getElementById('editor').value = file.text || ''; document.getElementById('status').textContent = 'Loaded!'; } catch(e) { document.getElementById('status').textContent = 'No saved file found.'; } setTimeout(() => document.getElementById('status').textContent = '', 2000); } load();<\/script>"
}
```

This app saves and loads a text file from the Documents folder. Try it out!

---

## OS Functions

Your custom apps can interact with the OS itself! Every custom app automatically has access to a global **`os`** object with the following functions. All of them are **async**, so use `await` when calling them.

### os.getVersion()

Returns the current version of E-Dog OS.

```js
const info = await os.getVersion();
console.log(info.version);  // e.g. "1.0.0"
```

### os.spawnError(text, type)

Displays an error dialog to the user.

```js
await os.spawnError('Something went wrong!', 'error');
```

- **text** — the message to display in the error dialog.
- **type** — the kind of dialog to show. Defaults to `'error'` if not specified.

### os.spawnBSOD(errorCode, errorName)

Triggers a full-screen crash window. Use this for critical, unrecoverable errors. Both parameters are optional — if omitted, a default BSOD is shown.

```js
await os.spawnBSOD('0x0000007E', 'SYSTEM_THREAD_EXCEPTION_NOT_HANDLED');
```

- **errorCode** — an error code to display on the crash screen (optional).
- **errorName** — a name or description for the error (optional).

**Warning:** This will crash the entire OS session.

### os.reboot()

Reboots E-Dog OS.

```js
await os.reboot();
```

### os.shutdown()

Shuts down E-Dog OS.

```js
await os.shutdown();
```
