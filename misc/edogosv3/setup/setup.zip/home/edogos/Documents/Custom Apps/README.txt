Now, with E-Dog OS, you can create your own apps! These apps will not have filesystem access. They will not be able to interact with the system (yet.)
But, for something basic like a calculator, it's fine.

If you want to make your own app, follow these instructions.

1) Make a new file. Name it whatever you want, but make sure it has the extension: ".app"
If it doesn't have the extension, E-Dog OS won't know that it's a custom app.
2) Right-click the file, click "Open With," and click "Text Editor." Now you can start writing code for the app!

Start with some curly braces. These can be found on the right side of your keyboard, near the Backspace and Enter keys.

{ App code goes here! }

The app needs the attributes: name, icon, width, height, and html.
"html" is the app's actual code. Everything else is info about the app and how it should be rendered.
Tip: "icon" can be replaced with "customIcon", but instead of any text, you need to specify something like "box". If it's not in the icon database, then it will not work. The icon database can be found in the folder of this text document.

Example app:
{
    "name": "Example App",
    "customIcon": "gear",
    "width": 300,
    "height": 200,
    "html": "<p>Demo App.</p>"
}

But, please note that you can't use double quotes inside of double quotes.

Right:
"html": "<p title='Demo App'>Demo App.</p>"

Wrong:
"html": "<p title="Demo App">Demo App.</p>"