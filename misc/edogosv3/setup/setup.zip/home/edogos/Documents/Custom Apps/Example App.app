{
    "name": "Example App",
    "customIcon": "gear",
    "width": 300,
    "height": 200,
    "html": "<p>Demo App.</p>"
}